"""Example package for testing private PyPI."""

__version__ = "1.0.0"

def hello():
    """Return a greeting."""
    return "Hello from example-package!"
